<?php
session_start();
if (isset($_SESSION['logged_id'])){
header('Location: index.php');
}
echo'LOG IG';

?>