<?php
session_start();
ob_start();
error_reporting(0);
require 'conf.php';

function validate_input($data) {
	$data = trim($data); //Removes whitespace and other predefined characters from both sides of a string
	$data = stripslashes($data); //Removes backslashes (\) from the user input data
	$data = htmlspecialchars($data); //Converts special characters to HTML entities
	return $data;
}


$password = validate_input($_POST['password']);
$email = validate_input($_POST['email']);

$searchQuery = "SELECT
                id, fullname,AES_DECRYPT(email, '$encKey') ,AES_DECRYPT(password, '$encKey')
                FROM users
                WHERE email= AES_ENCRYPT('$email','$encKey') 
                AND password =AES_ENCRYPT('$password','$encKey')"
                or die($db-> $error);
      
$result = mysqli_query($db, $searchQuery);

$num = mysqli_num_rows($result);

if($num!=0){ 
    $data = mysqli_fetch_row($result);
    $id_ = $data[0];
    $fullname_ = $data[1];
    $email_ = $data[2];
    $password_ = $data[3];
    
if($email == $email_ && $password == $password_ ){
    $_SESSION['logged_id'] = 
        header("Location:loginPage.php");
    } 
}else{
    
    header("Location:signup.php");
    

}
?>